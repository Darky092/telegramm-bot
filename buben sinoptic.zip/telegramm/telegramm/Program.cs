﻿using Telegram.Bot.Polling;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;
using Telegram.Bot.Types;
using Telegram.Bot;




Dictionary<string, string> regstration = new Dictionary<string, string>();
Dictionary<string, string> weatherToDay = new Dictionary<string, string>();
Dictionary<string, string> weathetTomorrow = new Dictionary<string, string>();

using var cts = new CancellationTokenSource();
var bot = new TelegramBotClient("7670333455:AAFMfNvnTJc6YnHOH_8Qkw_E03TQVM26SB4");
var me = await bot.GetMeAsync();

bool sss = false;
string name = "";

bot.OnError += OnError;
bot.OnMessage += OnMessage;
bot.OnUpdate += OnUpdate;
Console.ReadLine();
cts.Cancel();




async Task OnError(Exception exception, HandleErrorSource source)
{
    Console.WriteLine(exception); 
}

async Task OnMessage(Message message, UpdateType type)
{
    {
        string choice = "";
        Random rnd = new Random();
      



        if (message.Text == "/start")
        {
            await bot.SendMessage(message.Chat.Id, "назовись смертный");
            name = message.Text;
            Console.WriteLine(name);
            Console.WriteLine(message.Text);
            sss = true;



        }



        else if (sss)
        {
            name = message.Text;
            regstration.Add(Convert.ToString(message.Chat.Id), name);

            var replyMarkup = new ReplyKeyboardMarkup(true).AddButtons("Предскажи погоду на сегодня", "Предскажи погоду на завтра");

            await bot.SendMessage(message.Chat.Id, $"{message.Text} что тебе нужно", replyMarkup: replyMarkup);

            Console.WriteLine(message.Text);
            sss = false;
            Console.WriteLine(sss);
            return;

        }




        else if (message.Text.ToLower() == "предскажи погоду на сегодня")
        {
            bool weather = weatherToDay.ContainsKey(Convert.ToString(DateTime.Today));

            if (weather)
            {
                await bot.SendMessage(message.Chat.Id, weatherToDay[Convert.ToString(DateTime.Today)]);

            }
            else
            {
                int random = rnd.Next(0, 5);
                string pogoda = "";
                switch (random)
                {
                    case 0:
                        pogoda = "Ясно";

                        break;
                    case 1:
                        pogoda = "пасмурно";

                        break;
                    case 2:
                        pogoda = "выброс";

                        break;
                    case 3:
                        pogoda = "холодно";

                        break;
                    case 4:
                        pogoda = "жарко";

                        break;


                }
                weatherToDay.Add(Convert.ToString(DateTime.Today), pogoda);
                await bot.SendMessage(message.Chat.Id, "бубен и йогурты сказали будет: " + weatherToDay[Convert.ToString(DateTime.Today)]);


            }

        }




        else if (message.Text.ToLower() == "предскажи погоду на завтра")
        {
            bool weather = weathetTomorrow.ContainsKey(Convert.ToString(DateTime.Today.AddDays(1)));

            if (weather)
            {
                await bot.SendMessage(message.Chat.Id, weathetTomorrow[Convert.ToString(DateTime.Today.AddDays(1))]);

            }
            else
            {
                int random = rnd.Next(0, 5);
                string pogoda = "";
                switch (random)
                {
                    case 0:
                        pogoda = "Ясно";

                        break;
                    case 1:
                        pogoda = "пасмурно";

                        break;
                    case 2:
                        pogoda = "темно";

                        break;
                    case 3:
                        pogoda = "ветренно";

                        break;
                    case 4:
                        pogoda = "дождь";

                        break;


                }
                weathetTomorrow.Add(Convert.ToString(DateTime.Today.AddDays(1)), pogoda);
                await bot.SendMessage(message.Chat.Id, "бубен и йогурты сказали: " + weathetTomorrow[Convert.ToString(DateTime.Today.AddDays(1))]);


            }

        }

    }
}


async Task OnUpdate(Update update)
{
    if (update is { CallbackQuery: { } query }) // non-null CallbackQuery
    {

    }
}